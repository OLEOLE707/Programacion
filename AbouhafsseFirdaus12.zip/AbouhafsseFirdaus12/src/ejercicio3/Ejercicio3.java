/*
 * Descripción: Imprimir dos strings por pantalla
 * Autor: Firdaus Abouhafsse
 * Fecha:23/09/2025
 */



package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num1=1, num2=2;
		
		char char1='a', char2= 'b';
		
		String cargo="capitán", nombre="Firdaus";
		
		System.out.println("La variable num1 es: "+num1+" y la variable num2 es: "+num2);
		
		System.out.print("Bienvenido, "+cargo+" "+nombre+", donde \""+cargo+"\" es el cargo y \""+nombre+"\" es el nombre.");
	}

}	