/*
 * Descripción: mostrar Este es mi primer programa Java al usuario
 * Autor: Firdaus Abouuhafsse
 * Fecha:23/09/2025
 */

package ejercicio1;

public class Ejercicio1 {

	public static void main(String[] args) {

		System.out.println("Este es mi primer programa Java");

	}

}
